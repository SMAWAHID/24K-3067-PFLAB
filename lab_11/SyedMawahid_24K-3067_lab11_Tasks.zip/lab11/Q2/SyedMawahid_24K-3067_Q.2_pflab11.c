#include <stdio.h>

struct Salary {
    float basicPay;
    float bonuses;
    float deductions;
};

struct Employees {
    int employee_ID;
    char employeeName[20];
    struct Salary data;
};

float netSalary(struct Employees emp)
{
    return emp.data.basicPay + emp.data.bonuses - emp.data.deductions;
}

void displayDetails(struct Employees emp[], int n)
{
	int i=0;
    for (i = 0; i < n; i++)
    {
        printf("\nEmployee %d ID is %d\n", i + 1, emp[i].employee_ID);
        printf("Employee Name: %s\n", emp[i].employeeName);
        printf("Basic Pay: %.2f\n", emp[i].data.basicPay);
        printf("Bonuses: %.2f\n", emp[i].data.bonuses);
        printf("Deductions: %.2f\n", emp[i].data.deductions);
        printf("Net Salary: %.2f\n", netSalary(emp[i]));
        
    }
}

int main()
{
    int n, i=0;
    printf("Enter the Number of Employees: ");
    scanf("%d", &n);
    getchar();

    struct Employees emp[n];

    for ( i = 0; i < n; i++)
    {
        printf("\nEnter the Employee's ID: ");
        scanf("%d", &emp[i].employee_ID);
        getchar();

        printf("Enter the Employee's Name: ");
        fgets(emp[i].employeeName, sizeof(emp[i].employeeName), stdin);

        printf("Enter the Employee's Basic Pay: ");
        scanf("%f", &emp[i].data.basicPay);

        printf("Enter the Employee's Bonuses: ");
        scanf("%f", &emp[i].data.bonuses);

        printf("Enter the Employee's Deductions: ");
        scanf("%f", &emp[i].data.deductions);
		
        getchar();
    }

    displayDetails(emp, n);

    return 0;
}

