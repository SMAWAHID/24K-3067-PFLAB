#include <stdio.h>
#include <stdlib.h>

void deleteContent(FILE *file1) 
{
    fclose(file1);
    file1 = fopen("file1.txt", "w");
    if (file1 == NULL) 
    {
        printf("Error opening the file for writing.\n");
        exit(1);
    }
}

int main() 
{
    FILE *file1;

    file1 = fopen("file1.txt", "r");
    if (file1 == NULL) 
    {
        printf("Error opening the file for reading.\n");
        return 1;
    }

    deleteContent(file1);

    printf("Content of the file has been successfully deleted.\n");

    fclose(file1);

    return 0;
}
