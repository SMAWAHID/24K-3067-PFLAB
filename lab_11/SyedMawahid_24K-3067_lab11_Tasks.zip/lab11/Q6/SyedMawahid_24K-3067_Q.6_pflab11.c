#include <stdio.h>
#include <time.h>

int main()
{
    FILE *file = fopen("log.txt", "a");

    if (file == NULL)
    {
        printf("Error opening file.\n");
        return 1;
    }

    time_t currentTime;
    time(&currentTime);

    fprintf(file, "%s", ctime(&currentTime));

    fclose(file);

    return 0;
}
