#include <stdio.h>
#include <stdlib.h>

void mergeFiles(FILE *file1, FILE *file2, FILE *outputFile) {
    char ch;

    while ((ch = fgetc(file1)) != EOF) {
        fputc(ch, outputFile);
    }
	fputc('\n', outputFile);
    while ((ch = fgetc(file2)) != EOF) {
        fputc(ch, outputFile);
    }
}

int main() {
    FILE *file1, *file2, *outputFile;
    char ch;

    file1 = fopen("file1.txt", "r");
    if (file1 == NULL) {
        printf("Error opening the first file for reading.\n");
        return 1;
    }

    file2 = fopen("file2.txt", "r");
    if (file2 == NULL) {
        printf("Error opening the second file for reading.\n");
        fclose(file1);
        return 1;
    }

    outputFile = fopen("output.txt", "w");
    if (outputFile == NULL) {
        printf("Error opening the output file for writing.\n");
        fclose(file1);
        fclose(file2);
        return 1;
    }

    mergeFiles(file1, file2, outputFile);

    printf("Files have been successfully merged into output.txt\n");

    fclose(outputFile);

    fclose(file1);
    fclose(file2);
    fclose(outputFile);

    return 0;
}
