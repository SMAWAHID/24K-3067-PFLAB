#include <stdio.h>
#include <string.h>

#define MAX_PLAYERS 11

struct Player
{
    char name[50];
    int age;
    char position[50];
};

struct Team
{
    char name[50];
    char sport[50];
    struct Player players[MAX_PLAYERS];
    int playerCount;
};

void addPlayers(struct Team teams[], int teamIndex)
{
    int playerCount;
    printf("\nHow many players do you want to add to the team \"%s\"? ", teams[teamIndex].name);
    scanf("%d", &playerCount);

    if (playerCount > MAX_PLAYERS)
    {
        printf("You can add a maximum of %d players.\n", MAX_PLAYERS);
        playerCount = MAX_PLAYERS;
    }

    for (int i = 0; i < playerCount; i++)
    {
        printf("\nEnter details for Player %d\n", i + 1);
        printf("Name: ");
        scanf(" %[^\n]", teams[teamIndex].players[i].name);

        printf("Age: ");
        scanf("%d", &teams[teamIndex].players[i].age);

        printf("Position: ");
        scanf(" %[^\n]", teams[teamIndex].players[i].position);
    }

    teams[teamIndex].playerCount = playerCount;
}

void displayTeams(struct Team teams[], int teamCount)
{
    for (int i = 0; i < teamCount; i++)
    {
        printf("\nTeam %d: %s\n", i + 1, teams[i].name);
        printf("Sport: %s\n", teams[i].sport);

        for (int j = 0; j < teams[i].playerCount; j++)
        {
            printf("\nPlayer %d\n", j + 1);
            printf("Name: %s\n", teams[i].players[j].name);
            printf("Age: %d\n", teams[i].players[j].age);
            printf("Position: %s\n", teams[i].players[j].position);
        }
    }
}

void searchByPosition(struct Team teams[], int teamCount)
{
    char position[50];
    printf("Enter the position to search for players: ");
    scanf(" %[^\n]", position);

    int found = 0;

    for (int i = 0; i < teamCount; i++)
    {
        for (int j = 0; j < teams[i].playerCount; j++)
        {
            if (strcmp(teams[i].players[j].position, position) == 0)
            {
                printf("\nTeam: %s\n", teams[i].name);
                printf("Player Name: %s\n", teams[i].players[j].name);
                printf("Age: %d\n", teams[i].players[j].age);
                printf("Position: %s\n", teams[i].players[j].position);
                found = 1;
            }
        }
    }

    if (!found)
    {
        printf("No players found with position %s.\n", position);
    }
}

int main()
{
    int MAX_TEAMS;
    printf("Enter the maximum number of teams: ");
    scanf("%d", &MAX_TEAMS);

    int teamCount = 0;
    struct Team teams[MAX_TEAMS];

    int choice;

    do
    {
        printf("\nMenu:\n");
        printf("1. Add a team\n");
        printf("2. Add players to a team\n");
        printf("3. Display all teams\n");
        printf("4. Search players by position\n");
        printf("5. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice)
        {
            case 1:
                if (teamCount >= MAX_TEAMS)
                {
                    printf("Maximum number of teams reached.\n");
                }
                else
                {
                    printf("\nEnter details for Team %d\n", teamCount + 1);
                    printf("Team Name: ");
                    scanf(" %[^\n]", teams[teamCount].name);

                    printf("Sport: ");
                    scanf(" %[^\n]", teams[teamCount].sport);

                    teams[teamCount].playerCount = 0;
                    teamCount++;
                }
                break;

            case 2:
                if (teamCount == 0)
                {
                    printf("No teams available. Please add a team first.\n");
                }
                else
                {
                    printf("Enter the team number to add players (1 to %d): ", teamCount);
                    int teamIndex;
                    scanf("%d", &teamIndex);

                    if (teamIndex < 1 || teamIndex > teamCount)
                    {
                        printf("Invalid team number.\n");
                    }
                    else
                    {
                        addPlayers(teams, teamIndex - 1);
                    }
                }
                break;

            case 3:
                if (teamCount == 0)
                {
                    printf("No teams to display.\n");
                }
                else
                {
                    displayTeams(teams, teamCount);
                }
                break;

            case 4:
                if (teamCount == 0)
                {
                    printf("No teams available. Please add a team first.\n");
                }
                else
                {
                    searchByPosition(teams, teamCount);
                }
                break;

            case 5:
                printf("Exiting the program.\n");
                break;

            default:
                printf("Invalid choice. Please try again.\n");
        }
    } while (choice != 5);

    return 0;
}
