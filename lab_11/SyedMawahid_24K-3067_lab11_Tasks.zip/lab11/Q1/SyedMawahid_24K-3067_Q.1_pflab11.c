#include <stdio.h>

int main()
{
	FILE *filePtr = fopen("example.txt", "r");
    char ch;
	if (filePtr == NULL)
	{
		printf("Error opening file.\n");
		return 1;
	}
    int count = 0, words = 0, line = 0;
	
	printf("File contents: \n");
	while ((ch = fgetc(filePtr)) != EOF)
	{
		count++;
        
		if(ch == ' ')
        {
            words++;
        }
        if(ch == '\n')
        {
            line++;
        }
	}
	fclose(filePtr);
    printf("Lines: %d\n", line);
	printf("Words: %d\n", words);
	printf("Characters: %d\n", count);
	
	return 0;
}
