#include<stdio.h>

int main()
{
	FILE *filePtr = fopen("exampleb.bin", "w");
	
	if (filePtr == NULL)
	{
		printf("Error creating file.\n");
		return 1;
	}
	printf("File created successfully.\n");
	fclose(filePtr);
		
	return 0;
}
