#include <stdio.h>
#include <stdio.h>
#include <stdlib.h>

struct threeNum{
	int n1;
	int n2;
	int n3;
};

int main()
{
	int n;
	
	struct threeNum num;
	
	FILE *fptr = fopen("program.bin", "rb");
	
	if (fptr == NULL)
	{
		printf("Error! opening file");
		return 1;
	}
	for (n = 1; n < 5; ++n)
	{
		fread(&num, sizeof(struct threeNum), 1, fptr);
		printf("n1: %d\nn2: %d\nn3: %d\n\n", num.nl, num.n2, num.n3);
		fclose(fptr);
	}
	return 0;
}