#include <stdio.h>
#include <stdio.h>
#include <stdlib.h>

struct threeNum{
	int n1;
	int n2;
	int n3;
};
int main(){
	int n;
	struct threeNum num;
	
	FILE *fptr = fopen("program.bin", "w");
	if (fptr == NULL) {
			
		printf("Error! opening file");
		return 1;
	}
	for (n = 1; n < 5; ++n)
	{
		num.nl = n;
		num. n2 = 5*n;
		num.n3 = 5*n + 1;
		fwrite(&num, sizeof(struct threeNum), 1, fptr);
	}
	
	printf("successfully written to binary file.");
	fclose(fptr);
	
	return 0;
}