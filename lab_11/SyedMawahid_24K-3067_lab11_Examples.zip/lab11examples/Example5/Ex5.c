
#include <stdio.h>
int main() {
	FILE *filePtr = fopen("example.txt", "a");
	
	if (filePtr == NULL) {
		printf("Error opening file.\n");
		return 1;
	}
	
	fprintf(filePtr, "Additional content added.\n"); fclose(filePtr);
	printf("Data appended to file.\n");
	
	return 0;
}