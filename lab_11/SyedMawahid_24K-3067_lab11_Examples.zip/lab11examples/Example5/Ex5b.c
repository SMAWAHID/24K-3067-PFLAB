#include <stdio.h>
#include <string.h>

int main() {
	FILE *filePtr = fopen("example.txt", "r");
	FILE *tempFile = fopen("temp.txt", "w");
	char line[256];
	
	if (filePtr == NULL || tempFile == NULL) {
		printf("Error opening file. \n");
		return 1;
	}
	// Copying Lines to the temporary file, excluding lines with "Hello" while (fgets(line, sizeof(line), filePtr) != NULL) {
	if (strstr(line, "Hello") == NULL) { // Skip Lines containing "Hello" 
		fputs(line, tempFile);
	}
	
	fclose(filePtr);
	fclose(tempFile);
	
	// Replace the original file with the modified file remove("example.txt");
	rename("temp.txt", "example.txt");
	printf("Specific content deleted successfully.\n");
	
	return 0;
}