#include<stdio.h>
#include<string.h>

struct Type{
char typeName[20];
};

struct Car {
char CarName [20]; char make[15]; char model[15]; char color[10]; int seats;
int engine;
int price;
struct Type Cartype;
};

int main()
{
	struct Car myCar;
	
	puts("Enter the name of your car: ");
	gets (myCar.CarName);
	
	puts("Enter the type of your car (Mini, Sedan, Sports, Luxury, SUV): ");
	gets (myCar.Cartype.typeName);
	
	puts("Enter the color of your car: ");
	gets(myCar.color);
	
	puts("Enter the make of your car: ");
	gets(myCar.make);
	
	puts("Enter the model of your car: ");
	gets (myCar.model);
	
	printf("Enter the no of seats in your car: ");
	scanf("%d", &myCar.seats);
	
	printf("Enter the engine capacity of your car: ");
	scanf("%d", &myCar.engine);
	
	printf("Enter the price of your car: ");
	scanf("%d", &myCar.price);
	
	printf("\n\nCar Name: %s", myCar.CarName);
	
	printf("\nCar Type: %s", myCar.Cartype.typeName);
	
	printf("\nCar Color: %s", myCar.color);
	
	printf("\nCar make: %s", myCar.make);
	
	printf("\nCar model: %s", myCar.model); printf("\nNo of Seats: %d", myCar.seats);
	
	printf("\nEngine (cc): %d", myCar.engine); printf("\nPrice: %d", myCar.price);
	
	return 0;
}
