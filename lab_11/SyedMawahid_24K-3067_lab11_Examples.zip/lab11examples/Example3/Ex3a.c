#include <stdio.h>

int main()
{
	FILE *filePtr = fopen("example.txt", "r"); char ch;
	if (filePtr == NULL)
	{
		printf("Error opening file.\n"); return 1;
	}
	
	printf("File contents: \n");
	while ((ch = fgetc(filePtr)) != EOF)
	{
		putchar(ch);
	}
	fclose(filePtr);
		
	return 0;
}
