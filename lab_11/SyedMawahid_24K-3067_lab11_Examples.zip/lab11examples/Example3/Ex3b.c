#include <stdio.h>
int main() {
	FILE *filePtr = fopen("example.txt", "w"); 
	if (filePtr == NULL)
	{
	printf("Error opening file. \n");
		return 1;
	}
	
	fprintf(filePtr, "Hello, File Handling in C!\n");
	fclose(filePtr);
	printf("Data written to file.\n");
	
	return 0;
}
