#include <stdio.h>
#include <string.h>

struct UniversityDetails {
	int uni_rankings;
	char uni_name[90];
};

struct student {
	int id;
	char name[50];
	float percentage;
	struct UniversityDetails data;
};

int main(){
	struct student std = {1, "Arif Hussain", 80.5, 285,"National University of Emerging Sciences"};
	printf("ID is %d\n", std.id);
	printf("Name is %s\n", std.name);
	printf("Student Percentage is %f\n", std.percentage);
	printf("University ranking is %d\n", std.data.uni_rankings);
	printf("University Name is %d\n", std.data.uni_name);
	
	return 0;
}
